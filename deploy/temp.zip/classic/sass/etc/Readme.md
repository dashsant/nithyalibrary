### ./sass/etc

This folder contains misc. support code for Sass builds when using the classic toolkit (global functions, etc.).