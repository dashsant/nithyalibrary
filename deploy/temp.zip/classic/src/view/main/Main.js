/**
 * This class is the main view for the application. It is specified in app.js as the
 * "mainView" property. That setting automatically applies the "viewport"
 * plugin causing this view to become the body element (i.e., the viewport).
 *
 * TODO - Replace this content of this view to suite the needs of your application.
 */
Ext.define('library.view.main.Main', {
    extend: 'Ext.Panel',
	xtype: 'app-main',
	id:'app-main',
	plugins:'responsive',
	mixins: ['Ext.mixin.Responsive'],
	height:'100%',
	width:'100%',
	border: false,
	bodyStyle:{
		backgroundImage:'url(/resources/Background.png) !important',
		backgroundRepeat: 'no-repeat !important',
		backgroundSize:'cover !important',
		margin: '0  !important',
		padding: '0 !important',
		border: '0 important',
		borderWidth: 0
	},	
    requires: [
        'Ext.window.MessageBox',
		'Ext.tab.Panel',
        'library.view.main.MainController',
        'library.view.main.MainModel',
        'library.view.main.List',
		'library.view.main.LibraryHome'
    ],
	viewModel: 'main',
	controller:'main',
	layout:'border',
	items:[
		{
			title: 'header',
			layout: {type:'vbox',align:'start', pack:'center'},
			xtype: 'component',
			region: 'north',
			header: false,
			html: '<span style="margin-left:15px"><q><i>If you want to retain anything in life, renounce the fear of losing it.</i></q><b>-- H. H. Paramahamsa Nithyananda</b></span>',
			cls: 'topWide',
			responsiveConfig: {
				wide: {
					margin:'0 0 0 15'
				},
				'width < 600': {
					title: 'Mfg Summary',
					height: 45
				}
			}
		},
		{
			title: 'header',
			layout:{type:'hbox', align:'fit'},
			xtype:'container',
			region: 'north',
			height: '17%',
			header: false,
			style:{'z-index':'1000000 !important'},bodyStyle:{'z-index':'1000000 !important'},
			items:[
				{xtype:'component',width:'30%',height:'70%',cls:'productlogo',html:'&nbsp;'},
				{xtype:'container',width:'40%',height:'80%',defaultButton:'btnSearch',
				 referenceHolder: true,
				 layout:{type:'hbox',align:'middle',pack:'center'},
				 items:[
					 { xtype: 'textfield', emptyText: 'Type to search', flex:3,name: 'searchText',
					 id: 'searchText'},
					 {
					   xtype: 'button',text:'Search',iconCls: 'x-fa fa-search',padding:'0 5',
					   border:false,height:'32px',flex:1,name: 'btnSearch',
					   handler : 'onSearchTextClick', // no scope given here
					   style: 'min-width:25px;background-color: rgb(141, 67, 54);font-size:18;color:#fff;font-weight: bold;text-indent:2px'
					 }
				 ]
				},
				{xtype:'component',width:'30%',height:'100%',cls:'swamijilogo',html:'&nbsp;'}
			]
		},		
		{
			title: 'contentArea',
			layout:{type:'hbox', align:'fit'},
			xtype: 'container',
			region: 'center',
			header: false,
			cls:'bodyclass',
			height:'82%',
			margin:'0 15 0 15',
			items:[
				{
					xtype:'libraryhome',
					id:'libraryhomePage',
					flex:1
				}
			],
			style:{
				color: 'white',
			}
		},		
		{
			title: 'footer',
			xtype: 'component',
			region: 'south',
			header: false,
			minHeight: 19,
			layout: {
				type: 'hbox', align:'center',pack:'center'
			},
			html: '<div style="text-align:center">Copyright © 2018 Nithyananda University Press ' +
			'<a href="https://www.facebook.com/nithyanandauniversitypress">'+
			'<img src="resources/facebook.svg" style="display:inline-block;width:28px !important;height:28px !important;margin-right:15px;position:relative;top:8px;">'+
			'</a>'+

			'<a href="http://twitter.com/SriNithyananda">'+
			'<img src="resources/twitter.svg" style="display:inline-block;width:18px !important;height:18px !important;margin-right:15px;position:relative;top:4px;">'+
			'</a>'+

			'<a href="http://www.youtube.com/nithyanandatv">'+
			'<img src="resources/youtube.svg" style="display:inline-block;width:28px !important;height:28px !important;position:relative;top:8px;margin-right:15px;">'+
			'</a>'+

			'<a href="mailto:enpublishers@nithyananda.org">'+
			'<i class="fa fa-envelope" style="color:#d94103;font-size:16px !important;position:relative;top:-1px"></i>'+
			'</a>'+

			'</div>',
			items:
			[
				{ xtype:'container',
				  layout:{type:'hbox',align:'center',pack: 'center'},
				  items:[
					{
						xtype:'component',
						name: 'mailto',
						padding: '0 0 0 25',
						html:'<a href="mailto:enpublishers@nithyananda.org"><div style="color:#d94103"><i class="fa fa-envelope" style="position:relative;top:-2px;font-size:16px !important;"></i></div></a>'
					}
				  ]
				}
			],
			style:{
				color: 'white',background:'transparent', 'font-weight': '700'
			}
		},		
	]

});